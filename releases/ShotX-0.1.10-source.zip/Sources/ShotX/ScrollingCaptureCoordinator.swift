import AppKit
import ScreenCaptureKit
import UniformTypeIdentifiers

enum LongCaptureLimits {
    static let warningHeight = 48_000
    static let maximumHeight = 60_000
    static let warningBytes = 800_000_000
    static let maximumBytes = 1_000_000_000

    static func isWarning(height: Int, bytes: Int) -> Bool { height >= warningHeight || bytes >= warningBytes }
    static func isMaximum(height: Int, bytes: Int) -> Bool { height >= maximumHeight || bytes >= maximumBytes }
}

@MainActor
final class ScrollingCaptureCoordinator {
    static let shared = ScrollingCaptureCoordinator()
    private var session: ScrollingSession?
    private var panel: ScrollingPanelController?
    private var scrollMonitors: [Any] = []
    private var pendingCapture: Task<Void, Never>?
    private var captureRequested = false
    private var captureRegion = CGRect.zero

    func start(display: SCDisplay, screen: NSScreen, localRect: CGRect, model: AppModel) async {
        let filter = SCContentFilter(display: display, excludingWindows: [])
        let scale = screen.backingScaleFactor
        let source = CGRect(x: max(0, localRect.minX), y: max(0, screen.frame.height - localRect.maxY), width: localRect.width, height: localRect.height).integral
        let session = ScrollingSession(filter: filter, source: source, width: Int((source.width * scale).rounded()), height: Int((source.height * scale).rounded()))
        self.session = session
        captureRegion = localRect.offsetBy(dx: screen.frame.minX, dy: screen.frame.minY)
        let panel = ScrollingPanelController(
            onCancel: { [weak self] in self?.cancel() },
            onPin: { [weak self] in self?.pin(model: model) },
            onSave: { [weak self] in self?.save(model: model) },
            onCopy: { [weak self] in self?.copy(model: model) }
        )
        self.panel = panel
        panel.show(screen: screen, region: captureRegion)
        await capture(model: model)
        installScrollCapture(model: model)
    }

    private func capture(model: AppModel) async {
        guard let session else { return }
        do {
            let outcome = try await session.capture()
            updatePanel(message: outcome)
            if session.atMaximum { updatePanel(message: "已达到长图上限，已保留当前结果") }
        } catch { updatePanel(message: "已暂停：无法读取连续内容。当前内容仍可保存") }
    }

    private func outputImage() -> NSImage? { session?.render().map { NSImage(cgImage: $0, size: NSSize(width: $0.width, height: $0.height)) } }

    private func pin(model: AppModel) {
        guard let image = outputImage() else { return }
        model.recentResult = .image(image); cancel(); PinWindowController.show(image)
    }

    private func copy(model: AppModel) {
        guard let image = outputImage() else { return }
        NSPasteboard.general.clearContents()
        if NSPasteboard.general.writeObjects([image]) { model.recentResult = .image(image); cancel() }
        else { model.showError("无法复制长图。当前结果仍保留，请重试或保存。") }
    }

    private func save(model: AppModel) {
        guard let image = outputImage(), let data = image.pngData else { return }
        let save = NSSavePanel(); save.allowedContentTypes = [.png]; save.nameFieldStringValue = ShotXOutputName.make(extension: "png")
        if let path = model.settings.lastSaveDirectory { save.directoryURL = URL(fileURLWithPath: path) }
        save.begin { [weak self, weak model] response in
            guard let self, let model, response == .OK, let url = save.url else { return }
            do { try data.write(to: url, options: .atomic); model.settings.lastSaveDirectory = url.deletingLastPathComponent().path; model.persist(); model.recentResult = .image(image); self.cancel() }
            catch { model.showError("保存长图失败。当前结果仍保留，请重试或另存为。") }
        }
    }

    private func installScrollCapture(model: AppModel) {
        let handler: (NSEvent) -> Void = { [weak self] event in
            guard let self, self.captureRegion.contains(NSEvent.mouseLocation), abs(event.scrollingDeltaY) > 0 else { return }
            self.queueCapture(model: model)
        }
        if let monitor = NSEvent.addGlobalMonitorForEvents(matching: .scrollWheel, handler: handler) { scrollMonitors.append(monitor) }
        if let monitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel, handler: { event in handler(event); return event }) { scrollMonitors.append(monitor) }
    }

    private func queueCapture(model: AppModel) {
        captureRequested = true
        guard pendingCapture == nil else { return }
        pendingCapture = Task { @MainActor [weak self] in
            guard let self else { return }
            while self.captureRequested, !Task.isCancelled {
                self.captureRequested = false
                try? await Task.sleep(for: .milliseconds(90))
                guard !Task.isCancelled else { break }
                await self.capture(model: model)
            }
            self.pendingCapture = nil
        }
    }

    private func cancel() {
        pendingCapture?.cancel(); pendingCapture = nil; captureRequested = false
        scrollMonitors.forEach(NSEvent.removeMonitor); scrollMonitors.removeAll()
        let closingPanel = panel; panel = nil
        closingPanel?.close(); session = nil
    }
    private func updatePanel(message: String? = nil) { panel?.update(image: session?.render(), height: session?.height ?? 0, warning: session?.warning ?? false, maximum: session?.atMaximum ?? false, message: message) }
}

private final class ScrollingSession {
    private let filter: SCContentFilter
    private let config = SCStreamConfiguration()
    private(set) var segments: [CGImage] = []
    private var frames: [CGImage] = []
    private(set) var warning = false
    private(set) var atMaximum = false

    var height: Int { segments.reduce(0) { $0 + $1.height } }

    init(filter: SCContentFilter, source: CGRect, width: Int, height: Int) {
        self.filter = filter
        config.sourceRect = source
        config.width = max(1, width)
        config.height = max(1, height)
        config.showsCursor = false
        config.captureResolution = .best
    }

    func capture() async throws -> String {
        guard !atMaximum else { return "已达到长图上限" }
        let image = try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: config)
        let segment: CGImage
        if let lastFrame = frames.last {
            guard let match = Self.overlap(old: lastFrame, new: image) else { return "已暂停：无法找到连续内容" }
            if abs(match.horizontalOffset) > 8 { return "已暂停：检测到横向移动" }
            if match.overlap < image.height / 5 { return "已暂停：滚动过快，请慢一些" }
            if match.overlap >= image.height - 2 { return "未检测到滚动；请向下滚动后采集下一段" }
            guard let cropped = image.cropping(to: CGRect(x: 0, y: match.overlap, width: image.width, height: image.height - match.overlap)) else { return "已暂停：无法读取连续内容" }
            segment = cropped
        } else { segment = image }
        let newHeight = height + segment.height
        let bytes = image.width * newHeight * 4
        warning = LongCaptureLimits.isWarning(height: newHeight, bytes: bytes)
        atMaximum = LongCaptureLimits.isMaximum(height: newHeight, bytes: bytes)
        guard !atMaximum else { return "已达到长图上限，已保留当前结果" }
        segments.append(segment)
        frames.append(image)
        return warning ? "接近长图上限，建议现在结束" : "已自动采集并拼接一段"
    }

    func render() -> CGImage? {
        guard let first = segments.first else { return nil }
        let total = height
        guard let context = CGContext(data: nil, width: first.width, height: total, bitsPerComponent: 8, bytesPerRow: first.width * 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        var y = total
        for image in segments { y -= image.height; context.draw(image, in: CGRect(x: 0, y: y, width: image.width, height: image.height)) }
        return context.makeImage()
    }

    private struct Match { let overlap: Int; let horizontalOffset: Int; let score: Int }

    private static func overlap(old: CGImage, new: CGImage) -> Match? {
        guard old.width == new.width, old.height == new.height,
              let oldBytes = rgba(old), let newBytes = rgba(new) else { return nil }
        var best: Match?
        let minimum = max(1, new.height / 5)
        let maximum = max(minimum, new.height * 9 / 10)
        let overlapStep = max(1, new.height / 80)
        for overlap in stride(from: minimum, through: maximum, by: overlapStep) {
            for dx in -12...12 {
                var difference = 0
                var samples = 0
                for row in stride(from: 0, to: overlap, by: max(1, overlap / 12)) {
                    for x in stride(from: 16, to: new.width - 16, by: max(1, new.width / 20)) {
                        let shifted = x + dx
                        guard shifted >= 0, shifted < new.width else { continue }
                        let oldIndex = ((old.height - overlap + row) * old.width + x) * 4
                        let newIndex = (row * new.width + shifted) * 4
                        difference += abs(Int(oldBytes[oldIndex]) - Int(newBytes[newIndex]))
                        difference += abs(Int(oldBytes[oldIndex + 1]) - Int(newBytes[newIndex + 1]))
                        difference += abs(Int(oldBytes[oldIndex + 2]) - Int(newBytes[newIndex + 2]))
                        samples += 3
                    }
                }
                guard samples > 0 else { continue }
                let match = Match(overlap: overlap, horizontalOffset: dx, score: difference / samples)
                if best == nil || match.score < best!.score { best = match }
            }
        }
        return (best?.score ?? 256) <= 30 ? best : nil
    }

    private static func rgba(_ image: CGImage) -> [UInt8]? {
        let row = image.width * 4
        var bytes = [UInt8](repeating: 0, count: row * image.height)
        guard let context = CGContext(data: &bytes, width: image.width, height: image.height, bitsPerComponent: 8, bytesPerRow: row, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        return bytes
    }
}

enum ScrollingCaptureLayout {
    static let toolbarSize = NSSize(width: 172, height: 46)
    static let gap: CGFloat = 16

    static func toolbarFrame(region: CGRect, visible: CGRect) -> CGRect {
        let bounds = visible.insetBy(dx: 8, dy: 8)
        let x = min(max(bounds.minX, region.maxX - toolbarSize.width), bounds.maxX - toolbarSize.width)
        let below = region.minY - gap - toolbarSize.height
        let y = below >= bounds.minY ? below : min(bounds.maxY - toolbarSize.height, region.maxY + gap)
        return CGRect(origin: CGPoint(x: x, y: y), size: toolbarSize)
    }

    static func previewFrame(imageSize: CGSize, region: CGRect, visible: CGRect) -> CGRect {
        guard imageSize.width > 0, imageSize.height > 0 else { return .zero }
        let ratio = imageSize.width / imageSize.height
        let fixedWidth = min(312, visible.width - gap * 2)
        let availableHeight = min(520, max(1, visible.maxY - max(visible.minY, region.minY)))
        let fixedWidthHeight = fixedWidth / ratio
        let size = ratio >= 0.624 && fixedWidthHeight <= availableHeight
            ? CGSize(width: fixedWidth, height: fixedWidthHeight)
            : CGSize(width: availableHeight * ratio, height: availableHeight)
        var x = region.maxX + gap
        if x + size.width > visible.maxX { x = region.minX - gap - size.width }
        x = min(max(visible.minX, x), visible.maxX - size.width)
        let y = min(max(visible.minY, region.minY), visible.maxY - size.height)
        return CGRect(origin: CGPoint(x: x, y: y), size: size)
    }
}

@MainActor
private final class ScrollingPanelController: NSWindowController {
    private let preview = NSImageView()
    private var selectionWindow: NSPanel?
    private var previewWindow: NSPanel?
    private weak var screen: NSScreen?
    private var region = CGRect.zero
    private let onCancel: () -> Void
    private let onPin: () -> Void
    private let onSave: () -> Void
    private let onCopy: () -> Void

    init(onCancel: @escaping () -> Void, onPin: @escaping () -> Void, onSave: @escaping () -> Void, onCopy: @escaping () -> Void) {
        self.onCancel = onCancel; self.onPin = onPin; self.onSave = onSave; self.onCopy = onCopy
        let window = NSPanel(contentRect: NSRect(origin: .zero, size: ScrollingCaptureLayout.toolbarSize), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        window.level = .screenSaver; window.becomesKeyOnlyIfNeeded = true; window.hidesOnDeactivate = false; window.isReleasedWhenClosed = false; window.sharingType = .none; window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        super.init(window: window)
        let root = NSView(frame: NSRect(origin: .zero, size: ScrollingCaptureLayout.toolbarSize)); root.wantsLayer = true; root.layer?.backgroundColor = NSColor(hex: "#333333")?.cgColor; root.layer?.cornerRadius = 12; root.layer?.shadowColor = NSColor.black.cgColor; root.layer?.shadowOpacity = 0.16; root.layer?.shadowRadius = 4; root.layer?.shadowOffset = CGSize(width: 0, height: -4)
        let buttons = [iconButton("close", "取消滚动截图", #selector(cancelPressed)), iconButton("pin", "贴图", #selector(pinPressed)), iconButton("save", "保存", #selector(savePressed)), iconButton("copy", "复制", #selector(copyPressed))]
        let row = NSStackView(views: buttons); row.orientation = .horizontal; row.spacing = 16; row.frame = NSRect(x: 18, y: 12, width: 136, height: 22); root.addSubview(row); window.contentView = root

        let previewWindow = overlayWindow(frame: .zero, ignoresMouse: true); previewWindow.contentView = preview; preview.imageScaling = .scaleProportionallyUpOrDown; preview.alphaValue = 0.4; preview.wantsLayer = true; preview.layer?.cornerRadius = 8; preview.layer?.masksToBounds = true; preview.setAccessibilityLabel("滚动截图实时预览"); self.previewWindow = previewWindow
    }

    required init?(coder: NSCoder) { fatalError() }

    func show(screen: NSScreen, region: CGRect) {
        self.screen = screen; self.region = region
        let selectionWindow = overlayWindow(frame: region, ignoresMouse: true); selectionWindow.contentView = ScrollingSelectionView(frame: NSRect(origin: .zero, size: region.size)); self.selectionWindow = selectionWindow; selectionWindow.orderFrontRegardless()
        window?.setFrame(ScrollingCaptureLayout.toolbarFrame(region: region, visible: screen.visibleFrame), display: true); window?.orderFrontRegardless()
    }

    func update(image: CGImage?, height: Int, warning: Bool, maximum: Bool, message: String?) {
        guard let image, let screen, let previewWindow else { return }
        preview.image = NSImage(cgImage: image, size: NSSize(width: image.width, height: image.height))
        let frame = ScrollingCaptureLayout.previewFrame(imageSize: CGSize(width: image.width, height: image.height), region: region, visible: screen.visibleFrame)
        preview.frame = NSRect(origin: .zero, size: frame.size); previewWindow.setFrame(frame, display: true); previewWindow.orderFrontRegardless()
        window?.setAccessibilityValue(message ?? "已保留 \(height) px\(maximum ? "，已达到上限" : warning ? "，接近上限" : "")")
    }

    override func close() { selectionWindow?.close(); previewWindow?.close(); selectionWindow = nil; previewWindow = nil; super.close() }
    @objc private func cancelPressed() { onCancel() }
    @objc private func pinPressed() { onPin() }
    @objc private func savePressed() { onSave() }
    @objc private func copyPressed() { onCopy() }

    private func iconButton(_ asset: String, _ label: String, _ action: Selector) -> NSButton {
        let packaged = Bundle.main.resourceURL?.appendingPathComponent("ShotX_ShotX.bundle")
        let bundle = packaged.flatMap(Bundle.init(url:)) ?? Bundle.module
        let image = (bundle.url(forResource: asset, withExtension: "svg").flatMap(NSImage.init(contentsOf:)) ?? NSImage()).shotXSized(NSSize(width: 22, height: 22))
        let button = NSButton(image: image, target: self, action: action); button.isBordered = false; button.imagePosition = .imageOnly; button.frame.size = NSSize(width: 22, height: 22); button.setAccessibilityLabel(label); button.toolTip = label; return button
    }

    private func overlayWindow(frame: CGRect, ignoresMouse: Bool) -> NSPanel {
        let panel = NSPanel(contentRect: frame, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false); panel.level = .screenSaver; panel.backgroundColor = .clear; panel.isOpaque = false; panel.hasShadow = false; panel.isMovable = false; panel.isMovableByWindowBackground = false; panel.ignoresMouseEvents = ignoresMouse; panel.isReleasedWhenClosed = false; panel.sharingType = .none; panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]; return panel
    }
}

private final class ScrollingSelectionView: NSView {
    override func draw(_ dirtyRect: NSRect) {
        let color = NSColor(hex: "#10AEFF")!
        let rect = bounds.insetBy(dx: 2, dy: 2)
        color.setStroke(); let frame = NSBezierPath(roundedRect: rect, xRadius: 8, yRadius: 8); frame.lineWidth = 2; frame.stroke()
        for (x, y, sx, sy) in [(rect.minX, rect.minY, 1.0, 1.0), (rect.maxX, rect.minY, -1.0, 1.0), (rect.minX, rect.maxY, 1.0, -1.0), (rect.maxX, rect.maxY, -1.0, -1.0)] {
            let path = NSBezierPath(); path.move(to: CGPoint(x: x + 26 * sx, y: y)); path.line(to: CGPoint(x: x + 8 * sx, y: y)); path.curve(to: CGPoint(x: x, y: y + 8 * sy), controlPoint1: CGPoint(x: x + 3 * sx, y: y), controlPoint2: CGPoint(x: x, y: y + 3 * sy)); path.line(to: CGPoint(x: x, y: y + 26 * sy)); path.lineWidth = 3; path.lineCapStyle = .round; path.stroke()
        }
        for (a, b) in [(CGPoint(x: rect.midX - 11, y: rect.minY), CGPoint(x: rect.midX + 11, y: rect.minY)), (CGPoint(x: rect.midX - 11, y: rect.maxY), CGPoint(x: rect.midX + 11, y: rect.maxY)), (CGPoint(x: rect.minX, y: rect.midY - 11), CGPoint(x: rect.minX, y: rect.midY + 11)), (CGPoint(x: rect.maxX, y: rect.midY - 11), CGPoint(x: rect.maxX, y: rect.midY + 11))] { let path = NSBezierPath(); path.move(to: a); path.line(to: b); path.lineWidth = 3; path.lineCapStyle = .round; path.stroke() }
    }
}
